﻿
namespace CoinTNet.UI.Common
{
    /// <summary>
    /// Defines UI contstants
    /// </summary>
    class Constants
    {
        public const string CandleAreaName = "Price";
        public const string PriceSerieName = "priceHistory";
    }
}
