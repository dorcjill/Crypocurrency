﻿
namespace CoinTNet.Common.Constants
{
    class ExchangesInternalCodes
    {
        public const string Bitstamp = "bitstamp";
        public const string Btce = "btce";
        public const string Cryptsy = "cryptsy";
    }
    class CurrencyCodes
    {
        public const string BTC = "BTC";
    }
}
